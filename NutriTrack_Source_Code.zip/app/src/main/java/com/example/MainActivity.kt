package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.Screen
import com.example.ui.NutriTrackViewModel
import com.example.ui.components.AddFoodBottomSheet
import com.example.ui.components.AddWaterDialog
import com.example.ui.components.DatePickerModal
import com.example.ui.components.NotificationInsightsDialog
import com.example.ui.components.NutriTrackBottomNav
import com.example.ui.components.NutriTrackHeader
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.DailyLogScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SignUpScreen
import com.example.ui.screens.WaterScreen
import com.example.ui.theme.NutriTrackTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: NutriTrackViewModel = viewModel()
            NutriTrackApp(viewModel = viewModel)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NutriTrackApp(viewModel: NutriTrackViewModel) {
    val isSessionLoaded by viewModel.isSessionLoaded.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

    val currentDateMeals by viewModel.currentDateMeals.collectAsStateWithLifecycle()
    val currentDateWater by viewModel.currentDateWater.collectAsStateWithLifecycle()
    val allMeals by viewModel.allMeals.collectAsStateWithLifecycle()
    val allWater by viewModel.allWater.collectAsStateWithLifecycle()

    val weeklyAnalytics by viewModel.weeklyAnalytics.collectAsStateWithLifecycle()
    val monthlyAnalytics by viewModel.monthlyAnalytics.collectAsStateWithLifecycle()
    val historyList by viewModel.historyList.collectAsStateWithLifecycle()
    val progressComparison by viewModel.progressComparison.collectAsStateWithLifecycle()

    val isAddFoodSheetOpen by viewModel.isAddFoodSheetOpen.collectAsStateWithLifecycle()
    val selectedMealForAdd by viewModel.selectedMealForAdd.collectAsStateWithLifecycle()
    val authError by viewModel.authError.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

    val selectedAnalyticsMonth by viewModel.selectedAnalyticsMonth.collectAsStateWithLifecycle()
    val selectedAnalyticsYear by viewModel.selectedAnalyticsYear.collectAsStateWithLifecycle()

    var isRegistering by remember { mutableStateOf(false) }
    var showDatePickerDialog by remember { mutableStateOf(false) }
    var showNotificationDialog by remember { mutableStateOf(false) }
    var showCustomWaterDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Handle toast messages
    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            scope.launch {
                snackbarHostState.showSnackbar(it)
                viewModel.clearToast()
            }
        }
    }

    NutriTrackTheme(darkTheme = isDarkMode) {
        if (!isSessionLoaded) {
            // Loading session state
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        } else if (currentUser == null) {
            // Auth Flow: First time user or logged-out user
            if (isRegistering) {
                BackHandler { isRegistering = false }
                SignUpScreen(
                    authError = authError,
                    onSignUp = { name, mobile, pass, confirmPass, weightKg ->
                        viewModel.register(name, mobile, pass, confirmPass, weightKg) {
                            isRegistering = false
                        }
                    },
                    onNavigateToLogin = { isRegistering = false }
                )
            } else {
                LoginScreen(
                    authError = authError,
                    onLogin = { mobile, pass, rememberMe ->
                        viewModel.login(mobile, pass, rememberMe) {}
                    },
                    onNavigateToSignUp = { isRegistering = true }
                )
            }
        } else {
            // Logged-in user main app
            if (currentScreen != Screen.DASHBOARD) {
                BackHandler {
                    viewModel.navigateTo(Screen.DASHBOARD)
                }
            }

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                topBar = {
                    NutriTrackHeader(
                        currentUser = currentUser,
                        selectedDate = selectedDate,
                        isDarkMode = isDarkMode,
                        onToggleDarkMode = { viewModel.toggleDarkMode() },
                        onNotificationClick = { showNotificationDialog = true },
                        onLogoutClick = { viewModel.logout() },
                        onProfileClick = { viewModel.navigateTo(Screen.PROFILE) },
                        modifier = Modifier.statusBarsPadding()
                    )
                },
                bottomBar = {
                    NutriTrackBottomNav(
                        currentScreen = currentScreen,
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                },
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "screenTransition"
                    ) { targetScreen ->
                        when (targetScreen) {
                            Screen.DASHBOARD -> DashboardScreen(
                                currentUser = currentUser,
                                selectedDate = selectedDate,
                                meals = currentDateMeals,
                                water = currentDateWater,
                                comparison = progressComparison,
                                onPreviousDay = { viewModel.goToPreviousDay() },
                                onNextDay = { viewModel.goToNextDay() },
                                onToday = { viewModel.goToToday() },
                                onSelectDateClick = { showDatePickerDialog = true },
                                onOpenAddFood = { viewModel.openAddFoodDialog(it) },
                                onDeleteFood = { viewModel.deleteFood(it) },
                                onQuickAddWater = { viewModel.addWater(it) },
                                onCustomAddWaterClick = { showCustomWaterDialog = true },
                                onNavigate = { viewModel.navigateTo(it) }
                            )

                            Screen.DAILY_LOG -> DailyLogScreen(
                                currentUser = currentUser,
                                selectedDate = selectedDate,
                                meals = currentDateMeals,
                                water = currentDateWater,
                                onPreviousDay = { viewModel.goToPreviousDay() },
                                onNextDay = { viewModel.goToNextDay() },
                                onToday = { viewModel.goToToday() },
                                onSelectDateClick = { showDatePickerDialog = true },
                                onOpenAddFood = { viewModel.openAddFoodDialog(it) },
                                onDeleteFood = { viewModel.deleteFood(it) },
                                onDeleteWater = { viewModel.deleteWater(it) },
                                onQuickAddWater = { viewModel.addWater(it) }
                            )

                            Screen.HISTORY -> HistoryScreen(
                                historyList = historyList,
                                selectedDate = selectedDate,
                                analyticsYear = selectedAnalyticsYear,
                                analyticsMonth = selectedAnalyticsMonth,
                                allMeals = allMeals,
                                allWater = allWater,
                                calorieTarget = currentUser?.dailyCalorieTarget ?: 2200,
                                onPreviousMonth = { viewModel.changeAnalyticsMonth(-1) },
                                onNextMonth = { viewModel.changeAnalyticsMonth(1) },
                                onDateClick = {
                                    viewModel.selectDate(it)
                                    viewModel.navigateTo(Screen.DAILY_LOG)
                                }
                            )

                            Screen.ANALYTICS -> AnalyticsScreen(
                                weeklyAnalytics = weeklyAnalytics,
                                monthlyAnalytics = monthlyAnalytics,
                                comparison = progressComparison,
                                onPreviousMonth = { viewModel.changeAnalyticsMonth(-1) },
                                onNextMonth = { viewModel.changeAnalyticsMonth(1) }
                            )

                            Screen.WATER -> WaterScreen(
                                currentWaterMl = currentDateWater.sumOf { it.amountMl },
                                targetWaterMl = currentUser?.dailyWaterTargetMl ?: 3000,
                                waterEntries = currentDateWater,
                                selectedDate = selectedDate,
                                onPreviousDay = { viewModel.goToPreviousDay() },
                                onNextDay = { viewModel.goToNextDay() },
                                onToday = { viewModel.goToToday() },
                                onSelectDateClick = { showDatePickerDialog = true },
                                onQuickAdd = { viewModel.addWater(it) },
                                onCustomAddClick = { showCustomWaterDialog = true },
                                onDeleteEntry = { viewModel.deleteWater(it) }
                            )

                            Screen.PROFILE -> ProfileScreen(
                                currentUser = currentUser,
                                isDarkMode = isDarkMode,
                                onToggleDarkMode = { viewModel.toggleDarkMode() },
                                onSaveTargets = { name, weightKg, dailyCal, dailyWater, b, l, e, d, ex ->
                                    viewModel.updateUserTargets(name, weightKg, dailyCal, dailyWater, b, l, e, d, ex)
                                },
                                onLogout = { viewModel.logout() }
                            )
                        }
                    }
                }
            }

            // Add Food Bottom Sheet Modal
            if (isAddFoodSheetOpen) {
                AddFoodBottomSheet(
                    sheetState = sheetState,
                    initialMealType = selectedMealForAdd,
                    onDismiss = { viewModel.closeAddFoodDialog() },
                    onAddFood = { mealType, foodName, quantity, unit, calories ->
                        viewModel.addFood(mealType, foodName, quantity, unit, calories)
                    }
                )
            }

            // Custom Water Input Dialog
            if (showCustomWaterDialog) {
                AddWaterDialog(
                    onDismiss = { showCustomWaterDialog = false },
                    onConfirm = {
                        viewModel.addWater(it)
                        showCustomWaterDialog = false
                    }
                )
            }

            // Date Picker Modal
            if (showDatePickerDialog) {
                DatePickerModal(
                    currentDate = selectedDate,
                    onDateSelected = { viewModel.selectDate(it) },
                    onDismiss = { showDatePickerDialog = false }
                )
            }

            // Notification Insights Dialog
            if (showNotificationDialog) {
                NotificationInsightsDialog(
                    consumedCalories = currentDateMeals.sumOf { it.calories },
                    targetCalories = currentUser?.dailyCalorieTarget ?: 2200,
                    waterIntakeMl = currentDateWater.sumOf { it.amountMl },
                    targetWaterMl = currentUser?.dailyWaterTargetMl ?: 3000,
                    onDismiss = { showNotificationDialog = false }
                )
            }
        }
    }
}
