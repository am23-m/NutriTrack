package com.example.data

import androidx.room.Entity

@Entity(
    tableName = "daily_records",
    primaryKeys = ["userId", "dateString"]
)
data class DailyRecordEntity(
    val userId: String,
    val dateString: String, // format "YYYY-MM-DD"
    val totalCalories: Int = 0,
    val waterIntakeMl: Int = 0,
    val calorieTarget: Int = 2200,
    val waterTargetMl: Int = 3000,
    val exerciseMinutes: Int = 0,
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
