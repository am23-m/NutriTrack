package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "meal_items")
data class MealItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val dateString: String, // format "YYYY-MM-DD"
    val mealType: String,   // "BREAKFAST", "EVENING", "DINNER", "EXTRA"
    val foodName: String,
    val quantity: Double,
    val unit: String,
    val calories: Int,
    val createdAt: Long = System.currentTimeMillis()
)
