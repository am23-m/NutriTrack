package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface NutriTrackDao {
    // User operations
    @Query("SELECT * FROM users WHERE mobile = :mobile LIMIT 1")
    suspend fun getUserByMobile(mobile: String): UserEntity?

    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    suspend fun getUserById(userId: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    // Meals operations
    @Query("SELECT * FROM meal_items WHERE userId = :userId AND dateString = :dateString ORDER BY id ASC")
    fun getMealsByDate(userId: String, dateString: String): Flow<List<MealItemEntity>>

    @Query("SELECT * FROM meal_items WHERE userId = :userId AND dateString BETWEEN :startDate AND :endDate ORDER BY dateString ASC, id ASC")
    fun getMealsBetweenDates(userId: String, startDate: String, endDate: String): Flow<List<MealItemEntity>>

    @Query("SELECT * FROM meal_items WHERE userId = :userId ORDER BY dateString DESC, id DESC")
    fun getAllMealsForUser(userId: String): Flow<List<MealItemEntity>>

    @Query("SELECT * FROM meal_items WHERE userId = :userId")
    suspend fun getAllMealsList(userId: String): List<MealItemEntity>

    @Query("SELECT * FROM meal_items WHERE userId = :userId AND dateString = :dateString")
    suspend fun getMealsForDateList(userId: String, dateString: String): List<MealItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeal(meal: MealItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeals(meals: List<MealItemEntity>)

    @Query("DELETE FROM meal_items WHERE id = :id AND userId = :userId")
    suspend fun deleteMeal(id: Long, userId: String)

    // Water operations
    @Query("SELECT * FROM water_entries WHERE userId = :userId AND dateString = :dateString ORDER BY timestamp ASC")
    fun getWaterByDate(userId: String, dateString: String): Flow<List<WaterEntryEntity>>

    @Query("SELECT * FROM water_entries WHERE userId = :userId AND dateString BETWEEN :startDate AND :endDate ORDER BY dateString ASC, timestamp ASC")
    fun getWaterBetweenDates(userId: String, startDate: String, endDate: String): Flow<List<WaterEntryEntity>>

    @Query("SELECT * FROM water_entries WHERE userId = :userId ORDER BY dateString DESC")
    fun getAllWaterForUser(userId: String): Flow<List<WaterEntryEntity>>

    @Query("SELECT * FROM water_entries WHERE userId = :userId")
    suspend fun getAllWaterList(userId: String): List<WaterEntryEntity>

    @Query("SELECT * FROM water_entries WHERE userId = :userId AND dateString = :dateString")
    suspend fun getWaterForDateList(userId: String, dateString: String): List<WaterEntryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWater(water: WaterEntryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWaterEntries(entries: List<WaterEntryEntity>)

    @Query("DELETE FROM water_entries WHERE id = :id AND userId = :userId")
    suspend fun deleteWater(id: Long, userId: String)

    // Daily Record operations (User ID -> Date -> Daily Data)
    @Query("SELECT * FROM daily_records WHERE userId = :userId AND dateString = :dateString LIMIT 1")
    suspend fun getDailyRecord(userId: String, dateString: String): DailyRecordEntity?

    @Query("SELECT * FROM daily_records WHERE userId = :userId AND dateString = :dateString LIMIT 1")
    fun observeDailyRecord(userId: String, dateString: String): Flow<DailyRecordEntity?>

    @Query("SELECT * FROM daily_records WHERE userId = :userId ORDER BY dateString DESC")
    fun getAllDailyRecords(userId: String): Flow<List<DailyRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDailyRecord(record: DailyRecordEntity)
}
