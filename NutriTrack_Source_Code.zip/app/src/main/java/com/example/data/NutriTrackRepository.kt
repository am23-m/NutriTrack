package com.example.data

import com.example.util.DateUtils
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class NutriTrackRepository(
    private val dao: NutriTrackDao,
    private val sessionManager: SessionManager
) {

    // Session Management
    fun getActiveUserId(): String? = sessionManager.getActiveUserId()

    fun saveSession(userId: String) = sessionManager.saveUserSession(userId)

    fun clearSession() = sessionManager.clearSession()

    // User Operations
    suspend fun getUserByMobile(mobile: String): UserEntity? {
        return dao.getUserByMobile(mobile.trim())
    }

    suspend fun getUserById(userId: String): UserEntity? {
        return dao.getUserById(userId)
    }

    suspend fun registerUser(
        name: String,
        mobile: String,
        passwordHash: String,
        weightKg: Double = 70.0
    ): UserEntity {
        val existing = dao.getUserByMobile(mobile.trim())
        if (existing != null) {
            return existing
        }
        val newUser = UserEntity(
            userId = UUID.randomUUID().toString(),
            name = name.trim(),
            mobile = mobile.trim(),
            passwordHash = passwordHash,
            weightKg = weightKg,
            dailyCalorieTarget = 2200,
            dailyWaterTargetMl = 3000,
            breakfastTarget = 500,
            lunchTarget = 650,
            eveningTarget = 400,
            dinnerTarget = 650,
            extraTarget = 250
        )
        dao.insertUser(newUser)
        // Ensure today's daily record is cleanly initialized with 0 consumed calories and 0 water
        ensureDailyRecord(newUser.userId, DateUtils.getTodayDate(), newUser.dailyCalorieTarget, newUser.dailyWaterTargetMl)
        return newUser
    }

    suspend fun updateUser(user: UserEntity) {
        dao.updateUser(user)
    }

    // Daily Record Operations (User ID -> Date -> Daily Data)
    suspend fun getDailyRecord(userId: String, dateString: String): DailyRecordEntity? {
        return dao.getDailyRecord(userId, dateString)
    }

    fun observeDailyRecord(userId: String, dateString: String): Flow<DailyRecordEntity?> {
        return dao.observeDailyRecord(userId, dateString)
    }

    fun getAllDailyRecords(userId: String): Flow<List<DailyRecordEntity>> {
        return dao.getAllDailyRecords(userId)
    }

    suspend fun ensureDailyRecord(
        userId: String,
        dateString: String,
        calorieTarget: Int,
        waterTargetMl: Int
    ): DailyRecordEntity {
        val existing = dao.getDailyRecord(userId, dateString)
        if (existing != null) {
            return existing
        }
        val dayMeals = dao.getMealsForDateList(userId, dateString)
        val dayWater = dao.getWaterForDateList(userId, dateString)
        val newRecord = DailyRecordEntity(
            userId = userId,
            dateString = dateString,
            totalCalories = dayMeals.sumOf { it.calories },
            waterIntakeMl = dayWater.sumOf { it.amountMl },
            calorieTarget = calorieTarget,
            waterTargetMl = waterTargetMl,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertDailyRecord(newRecord)
        return newRecord
    }

    suspend fun syncDailyTotals(userId: String, dateString: String) {
        val user = dao.getUserById(userId)
        val cTarget = user?.dailyCalorieTarget ?: 2200
        val wTarget = user?.dailyWaterTargetMl ?: 3000

        val dayMeals = dao.getMealsForDateList(userId, dateString)
        val dayWater = dao.getWaterForDateList(userId, dateString)

        val updatedRecord = DailyRecordEntity(
            userId = userId,
            dateString = dateString,
            totalCalories = dayMeals.sumOf { it.calories },
            waterIntakeMl = dayWater.sumOf { it.amountMl },
            calorieTarget = cTarget,
            waterTargetMl = wTarget,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertDailyRecord(updatedRecord)
    }

    // Meal Operations
    fun getMealsByDate(userId: String, dateString: String): Flow<List<MealItemEntity>> {
        return dao.getMealsByDate(userId, dateString)
    }

    fun getAllMealsForUser(userId: String): Flow<List<MealItemEntity>> {
        return dao.getAllMealsForUser(userId)
    }

    suspend fun insertMeal(meal: MealItemEntity): Long {
        val id = dao.insertMeal(meal)
        syncDailyTotals(meal.userId, meal.dateString)
        return id
    }

    suspend fun deleteMeal(id: Long, userId: String, dateString: String) {
        dao.deleteMeal(id, userId)
        syncDailyTotals(userId, dateString)
    }

    // Water Operations
    fun getWaterByDate(userId: String, dateString: String): Flow<List<WaterEntryEntity>> {
        return dao.getWaterByDate(userId, dateString)
    }

    fun getAllWaterForUser(userId: String): Flow<List<WaterEntryEntity>> {
        return dao.getAllWaterForUser(userId)
    }

    suspend fun insertWater(water: WaterEntryEntity): Long {
        val id = dao.insertWater(water)
        syncDailyTotals(water.userId, water.dateString)
        return id
    }

    suspend fun deleteWater(id: Long, userId: String, dateString: String) {
        dao.deleteWater(id, userId)
        syncDailyTotals(userId, dateString)
    }
}
