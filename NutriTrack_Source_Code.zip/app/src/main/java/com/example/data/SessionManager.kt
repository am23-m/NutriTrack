package com.example.data

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("nutritrack_session_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_ACTIVE_USER_ID = "active_logged_in_user_id"
    }

    fun saveUserSession(userId: String) {
        prefs.edit().putString(KEY_ACTIVE_USER_ID, userId).apply()
    }

    fun getActiveUserId(): String? {
        return prefs.getString(KEY_ACTIVE_USER_ID, null)
    }

    fun clearSession() {
        prefs.edit().remove(KEY_ACTIVE_USER_ID).apply()
    }
}
