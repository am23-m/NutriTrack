package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val userId: String,
    val name: String,
    val mobile: String,
    val passwordHash: String,
    val weightKg: Double = 70.0,
    val dailyCalorieTarget: Int = 2200,
    val dailyWaterTargetMl: Int = 3000,
    val breakfastTarget: Int = 500,
    val lunchTarget: Int = 650,
    val eveningTarget: Int = 400,
    val dinnerTarget: Int = 650,
    val extraTarget: Int = 250,
    val createdAt: Long = System.currentTimeMillis()
)
