package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "water_entries")
data class WaterEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val dateString: String, // "YYYY-MM-DD"
    val amountMl: Int,
    val timestamp: Long = System.currentTimeMillis()
)
