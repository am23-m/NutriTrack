package com.example.model

enum class MealType(
    val id: String,
    val title: String,
    val icon: String,
    val defaultTarget: Int
) {
    BREAKFAST("BREAKFAST", "Breakfast", "🌅", 500),
    LUNCH("LUNCH", "Lunch", "☀️", 650),
    EVENING("EVENING", "Evening", "🌆", 400),
    DINNER("DINNER", "Dinner", "🌙", 650),
    EXTRA("EXTRA", "Extra", "🥜", 250);

    companion object {
        fun fromId(id: String): MealType {
            return entries.find { it.id.equals(id, ignoreCase = true) } ?: BREAKFAST
        }
    }
}

data class DaySummary(
    val dateString: String,
    val dayOfWeek: String,
    val dayOfMonth: Int,
    val monthName: String,
    val totalCalories: Int,
    val calorieTarget: Int,
    val waterIntakeMl: Int,
    val waterTargetMl: Int,
    val status: String
)

data class WeeklyAnalytics(
    val days: List<DaySummary> = emptyList(),
    val averageCalories: Int = 0,
    val totalCalories: Int = 0,
    val averageWaterL: Double = 0.0,
    val bestHydrationDay: String = "—",
    val daysTracked: Int = 0,
    val targetCompletionPercentage: Int = 0
)

data class MonthlyAnalytics(
    val monthTitle: String = "",
    val year: Int = 2026,
    val month: Int = 9,
    val averageDailyCalories: Int = 0,
    val averageWaterL: Double = 0.0,
    val totalCaloriesLogged: Int = 0,
    val daysTracked: Int = 0,
    val totalDaysInMonth: Int = 30,
    val calorieTrend: List<Pair<Int, Int>> = emptyList(), // Pair(dayNumber, calories)
    val waterTrend: List<Pair<Int, Double>> = emptyList(), // Pair(dayNumber, litres)
    val calorieTarget: Int = 2200
)

data class ProgressComparison(
    val todayCalories: Int = 0,
    val yesterdayCalories: Int = 0,
    val calorieDelta: Int = 0, // today - yesterday
    val caloriePercentChange: Double = 0.0,
    val todayWaterL: Double = 0.0,
    val yesterdayWaterL: Double = 0.0,
    val waterDeltaL: Double = 0.0,
    val thisWeekAvgCalories: Int = 0,
    val lastWeekAvgCalories: Int = 0,
    val thisWeekWaterL: Double = 0.0,
    val lastWeekWaterL: Double = 0.0,
    val thisMonthAvgCalories: Int = 0,
    val lastMonthAvgCalories: Int = 0
)

enum class Screen(val title: String) {
    DASHBOARD("Dashboard"),
    DAILY_LOG("Daily Log"),
    HISTORY("History"),
    ANALYTICS("Analytics"),
    WATER("Water"),
    PROFILE("Profile")
}
