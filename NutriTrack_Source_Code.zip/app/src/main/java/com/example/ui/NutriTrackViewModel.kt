package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MealItemEntity
import com.example.data.NutriTrackDatabase
import com.example.data.NutriTrackRepository
import com.example.data.SessionManager
import com.example.data.UserEntity
import com.example.data.WaterEntryEntity
import com.example.model.DaySummary
import com.example.model.MealType
import com.example.model.MonthlyAnalytics
import com.example.model.ProgressComparison
import com.example.model.Screen
import com.example.model.WeeklyAnalytics
import com.example.util.DateUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.abs

class NutriTrackViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: NutriTrackRepository
    val context = application.applicationContext

    private val _isSessionLoaded = MutableStateFlow(false)
    val isSessionLoaded: StateFlow<Boolean> = _isSessionLoaded.asStateFlow()

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _selectedDate = MutableStateFlow(DateUtils.getTodayDate())
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _currentScreen = MutableStateFlow(Screen.DASHBOARD)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _isAddFoodSheetOpen = MutableStateFlow(false)
    val isAddFoodSheetOpen: StateFlow<Boolean> = _isAddFoodSheetOpen.asStateFlow()

    private val _selectedMealForAdd = MutableStateFlow(MealType.BREAKFAST)
    val selectedMealForAdd: StateFlow<MealType> = _selectedMealForAdd.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _selectedAnalyticsMonth = MutableStateFlow(9)
    val selectedAnalyticsMonth: StateFlow<Int> = _selectedAnalyticsMonth.asStateFlow()

    private val _selectedAnalyticsYear = MutableStateFlow(2026)
    val selectedAnalyticsYear: StateFlow<Int> = _selectedAnalyticsYear.asStateFlow()

    // Meals for the selected date
    private val _currentDateMeals = MutableStateFlow<List<MealItemEntity>>(emptyList())
    val currentDateMeals: StateFlow<List<MealItemEntity>> = _currentDateMeals.asStateFlow()

    // Water entries for the selected date
    private val _currentDateWater = MutableStateFlow<List<WaterEntryEntity>>(emptyList())
    val currentDateWater: StateFlow<List<WaterEntryEntity>> = _currentDateWater.asStateFlow()

    // All meals and water for the current user
    private val _allMeals = MutableStateFlow<List<MealItemEntity>>(emptyList())
    val allMeals: StateFlow<List<MealItemEntity>> = _allMeals.asStateFlow()

    private val _allWater = MutableStateFlow<List<WaterEntryEntity>>(emptyList())
    val allWater: StateFlow<List<WaterEntryEntity>> = _allWater.asStateFlow()

    private var mealsJob: Job? = null
    private var waterJob: Job? = null

    init {
        val database = NutriTrackDatabase.getDatabase(application)
        val sessionManager = SessionManager(application)
        repository = NutriTrackRepository(database.dao(), sessionManager)

        // Check persistent login session on startup
        viewModelScope.launch {
            val activeUserId = repository.getActiveUserId()
            if (activeUserId != null) {
                val user = repository.getUserById(activeUserId)
                if (user != null) {
                    _currentUser.value = user
                    observeUserData(user.userId)
                    repository.ensureDailyRecord(
                        user.userId,
                        _selectedDate.value,
                        user.dailyCalorieTarget,
                        user.dailyWaterTargetMl
                    )
                } else {
                    repository.clearSession()
                    _currentUser.value = null
                }
            } else {
                _currentUser.value = null
            }
            _isSessionLoaded.value = true
        }
    }

    private fun observeUserData(userId: String) {
        mealsJob?.cancel()
        waterJob?.cancel()

        mealsJob = viewModelScope.launch {
            repository.getAllMealsForUser(userId).collect { meals ->
                _allMeals.value = meals
                refreshCurrentDateData()
            }
        }
        waterJob = viewModelScope.launch {
            repository.getAllWaterForUser(userId).collect { water ->
                _allWater.value = water
                refreshCurrentDateData()
            }
        }
    }

    private fun refreshCurrentDateData() {
        val date = _selectedDate.value
        _currentDateMeals.value = _allMeals.value.filter { it.dateString == date }
        _currentDateWater.value = _allWater.value.filter { it.dateString == date }
    }

    fun selectDate(dateString: String) {
        _selectedDate.value = dateString
        refreshCurrentDateData()
        ensureDailyRecordForDate(dateString)
    }

    fun goToPreviousDay() {
        _selectedDate.value = DateUtils.addDays(_selectedDate.value, -1)
        refreshCurrentDateData()
        ensureDailyRecordForDate(_selectedDate.value)
    }

    fun goToNextDay() {
        _selectedDate.value = DateUtils.addDays(_selectedDate.value, 1)
        refreshCurrentDateData()
        ensureDailyRecordForDate(_selectedDate.value)
    }

    fun goToToday() {
        _selectedDate.value = DateUtils.getTodayDate()
        refreshCurrentDateData()
        ensureDailyRecordForDate(_selectedDate.value)
    }

    private fun ensureDailyRecordForDate(date: String) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            repository.ensureDailyRecord(
                user.userId,
                date,
                user.dailyCalorieTarget,
                user.dailyWaterTargetMl
            )
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun openAddFoodDialog(mealType: MealType = MealType.BREAKFAST) {
        _selectedMealForAdd.value = mealType
        _isAddFoodSheetOpen.value = true
    }

    fun closeAddFoodDialog() {
        _isAddFoodSheetOpen.value = false
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    // Auth methods
    fun login(mobile: String, pass: String, rememberMe: Boolean, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _authError.value = null
            if (mobile.isBlank() || pass.isBlank()) {
                _authError.value = "Please enter both mobile number and password."
                return@launch
            }
            val user = repository.getUserByMobile(mobile.trim())
            if (user == null || user.passwordHash != pass) {
                _authError.value = "Invalid mobile number or password."
                return@launch
            }
            if (rememberMe) {
                repository.saveSession(user.userId)
            }
            _currentUser.value = user
            observeUserData(user.userId)
            repository.ensureDailyRecord(
                user.userId,
                _selectedDate.value,
                user.dailyCalorieTarget,
                user.dailyWaterTargetMl
            )
            showToast("Welcome back, ${user.name}!")
            onSuccess()
        }
    }

    fun register(
        name: String,
        mobile: String,
        pass: String,
        confirmPass: String,
        weightKg: Double = 70.0,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            _authError.value = null
            if (name.isBlank() || mobile.isBlank() || pass.isBlank()) {
                _authError.value = "All fields are required."
                return@launch
            }
            if (pass != confirmPass) {
                _authError.value = "Passwords do not match."
                return@launch
            }
            if (pass.length < 6) {
                _authError.value = "Password must be at least 6 characters."
                return@launch
            }
            val existing = repository.getUserByMobile(mobile.trim())
            if (existing != null) {
                _authError.value = "An account with this mobile number already exists."
                return@launch
            }
            val newUser = repository.registerUser(name.trim(), mobile.trim(), pass, weightKg)
            repository.saveSession(newUser.userId)
            _currentUser.value = newUser
            observeUserData(newUser.userId)
            showToast("Account created successfully!")
            onSuccess()
        }
    }

    fun logout() {
        mealsJob?.cancel()
        waterJob?.cancel()
        repository.clearSession()
        _currentUser.value = null
        _currentDateMeals.value = emptyList()
        _currentDateWater.value = emptyList()
        _allMeals.value = emptyList()
        _allWater.value = emptyList()
        _currentScreen.value = Screen.DASHBOARD
        showToast("Logged out successfully.")
    }

    // Food Operations
    fun addFood(mealType: MealType, foodName: String, quantity: Double, unit: String, calories: Int) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val meal = MealItemEntity(
                userId = user.userId,
                dateString = _selectedDate.value,
                mealType = mealType.id,
                foodName = foodName.trim(),
                quantity = quantity,
                unit = unit.trim(),
                calories = calories
            )
            repository.insertMeal(meal)
            _isAddFoodSheetOpen.value = false
            showToast("Added $foodName (${calories} kcal) to ${mealType.title}")
        }
    }

    fun deleteFood(mealId: Long) {
        val user = _currentUser.value ?: return
        val meal = _allMeals.value.find { it.id == mealId }
        val date = meal?.dateString ?: _selectedDate.value
        viewModelScope.launch {
            repository.deleteMeal(mealId, user.userId, date)
            showToast("Meal item removed")
        }
    }

    // Water Operations
    fun addWater(amountMl: Int) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val water = WaterEntryEntity(
                userId = user.userId,
                dateString = _selectedDate.value,
                amountMl = amountMl
            )
            repository.insertWater(water)
            showToast("Added +${amountMl} ml water")
        }
    }

    fun deleteWater(entryId: Long) {
        val user = _currentUser.value ?: return
        val entry = _allWater.value.find { it.id == entryId }
        val date = entry?.dateString ?: _selectedDate.value
        viewModelScope.launch {
            repository.deleteWater(entryId, user.userId, date)
            showToast("Water entry removed")
        }
    }

    fun updateUserTargets(
        name: String,
        weightKg: Double,
        dailyCalorie: Int,
        dailyWater: Int,
        breakfast: Int,
        lunch: Int,
        evening: Int,
        dinner: Int,
        extra: Int
    ) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val updated = user.copy(
                name = name.ifBlank { user.name },
                weightKg = weightKg,
                dailyCalorieTarget = dailyCalorie,
                dailyWaterTargetMl = dailyWater,
                breakfastTarget = breakfast,
                lunchTarget = lunch,
                eveningTarget = evening,
                dinnerTarget = dinner,
                extraTarget = extra
            )
            repository.updateUser(updated)
            _currentUser.value = updated
            // Update today's daily record target
            repository.ensureDailyRecord(
                updated.userId,
                _selectedDate.value,
                updated.dailyCalorieTarget,
                updated.dailyWaterTargetMl
            )
            showToast("Profile & targets updated successfully!")
        }
    }

    fun changeAnalyticsMonth(offset: Int) {
        var m = _selectedAnalyticsMonth.value + offset
        var y = _selectedAnalyticsYear.value
        if (m < 1) {
            m = 12
            y -= 1
        } else if (m > 12) {
            m = 1
            y += 1
        }
        _selectedAnalyticsMonth.value = m
        _selectedAnalyticsYear.value = y
    }

    // Progress Comparison calculated strictly from user's saved data
    val progressComparison: StateFlow<ProgressComparison> = combine(_allMeals, _allWater, _selectedDate) { meals, water, date ->
        val yesterday = DateUtils.addDays(date, -1)

        val todayCals = meals.filter { it.dateString == date }.sumOf { it.calories }
        val yesterdayCals = meals.filter { it.dateString == yesterday }.sumOf { it.calories }
        val calDelta = todayCals - yesterdayCals
        val calPercent = if (yesterdayCals > 0) ((calDelta.toDouble() / yesterdayCals) * 100) else 0.0

        val todayWaterMl = water.filter { it.dateString == date }.sumOf { it.amountMl }
        val yesterdayWaterMl = water.filter { it.dateString == yesterday }.sumOf { it.amountMl }
        val waterDeltaL = (todayWaterMl - yesterdayWaterMl) / 1000.0

        // This week (past 7 days window up to selected date)
        var thisWeekCals = 0
        var thisWeekDays = 0
        var thisWeekWater = 0
        for (i in 0..6) {
            val d = DateUtils.addDays(date, -i)
            val c = meals.filter { it.dateString == d }.sumOf { it.calories }
            val w = water.filter { it.dateString == d }.sumOf { it.amountMl }
            if (c > 0 || w > 0) {
                thisWeekCals += c
                thisWeekDays++
                thisWeekWater += w
            }
        }
        val thisWeekAvgCal = if (thisWeekDays > 0) thisWeekCals / thisWeekDays else todayCals
        val thisWeekWaterL = if (thisWeekDays > 0) (thisWeekWater / thisWeekDays) / 1000.0 else (todayWaterMl / 1000.0)

        // Last week (preceding 7 days window: days -7 to -13)
        var lastWeekCals = 0
        var lastWeekDays = 0
        var lastWeekWater = 0
        for (i in 7..13) {
            val d = DateUtils.addDays(date, -i)
            val c = meals.filter { it.dateString == d }.sumOf { it.calories }
            val w = water.filter { it.dateString == d }.sumOf { it.amountMl }
            if (c > 0 || w > 0) {
                lastWeekCals += c
                lastWeekDays++
                lastWeekWater += w
            }
        }
        val lastWeekAvgCal = if (lastWeekDays > 0) lastWeekCals / lastWeekDays else 0
        val lastWeekWaterL = if (lastWeekDays > 0) (lastWeekWater / lastWeekDays) / 1000.0 else 0.0

        // Monthly averages from real user history
        val thisMonthPrefix = date.substring(0, minOf(7, date.length))
        val monthMeals = meals.filter { it.dateString.startsWith(thisMonthPrefix) }
        val monthDaysCount = monthMeals.map { it.dateString }.distinct().size
        val thisMonthAvg = if (monthDaysCount > 0) monthMeals.sumOf { it.calories } / monthDaysCount else todayCals

        ProgressComparison(
            todayCalories = todayCals,
            yesterdayCalories = yesterdayCals,
            calorieDelta = calDelta,
            caloriePercentChange = calPercent,
            todayWaterL = todayWaterMl / 1000.0,
            yesterdayWaterL = yesterdayWaterMl / 1000.0,
            waterDeltaL = waterDeltaL,
            thisWeekAvgCalories = thisWeekAvgCal,
            lastWeekAvgCalories = lastWeekAvgCal,
            thisWeekWaterL = thisWeekWaterL,
            lastWeekWaterL = lastWeekWaterL,
            thisMonthAvgCalories = thisMonthAvg,
            lastMonthAvgCalories = if (lastWeekAvgCal > 0) lastWeekAvgCal else 0
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ProgressComparison())

    // Weekly Analytics from real saved data
    val weeklyAnalytics: StateFlow<WeeklyAnalytics> = combine(_allMeals, _allWater, _selectedDate, _currentUser) { meals, water, date, user ->
        val target = user?.dailyCalorieTarget ?: 2200
        val waterTarget = user?.dailyWaterTargetMl ?: 3000

        val days = mutableListOf<DaySummary>()
        var totalCal = 0
        var totalWater = 0
        var daysTrackedCount = 0
        var bestHydrationAmount = 0
        var bestHydrationDay = "—"

        for (i in 6 downTo 0) {
            val dStr = DateUtils.addDays(date, -i)
            val dayCals = meals.filter { it.dateString == dStr }.sumOf { it.calories }
            val dayWater = water.filter { it.dateString == dStr }.sumOf { it.amountMl }
            val dow = DateUtils.getDayOfWeekShort(dStr)
            val dom = DateUtils.getDayOfMonth(dStr)

            val status = when {
                dayCals == 0 && dayWater == 0 -> "No Data"
                abs(dayCals - target) <= 150 -> "Achieved"
                dayCals < target -> "Under Target"
                else -> "Over Target"
            }

            if (dayCals > 0 || dayWater > 0) {
                totalCal += dayCals
                totalWater += dayWater
                daysTrackedCount++
                if (dayWater > bestHydrationAmount) {
                    bestHydrationAmount = dayWater
                    bestHydrationDay = "$dow (${dayWater / 1000.0}L)"
                }
            }

            days.add(
                DaySummary(
                    dateString = dStr,
                    dayOfWeek = dow,
                    dayOfMonth = dom,
                    monthName = DateUtils.formatShortMonthDay(dStr),
                    totalCalories = dayCals,
                    calorieTarget = target,
                    waterIntakeMl = dayWater,
                    waterTargetMl = waterTarget,
                    status = status
                )
            )
        }

        val avgCal = if (daysTrackedCount > 0) totalCal / daysTrackedCount else 0
        val avgWater = if (daysTrackedCount > 0) (totalWater / daysTrackedCount) / 1000.0 else 0.0
        val completionPct = if (daysTrackedCount > 0) ((daysTrackedCount.toDouble() / 7) * 100).toInt() else 0

        WeeklyAnalytics(
            days = days,
            averageCalories = avgCal,
            totalCalories = totalCal,
            averageWaterL = avgWater,
            bestHydrationDay = bestHydrationDay,
            daysTracked = daysTrackedCount,
            targetCompletionPercentage = completionPct
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), WeeklyAnalytics())

    // Monthly Analytics from real saved data
    val monthlyAnalytics: StateFlow<MonthlyAnalytics> = combine(
        _allMeals, _allWater, _selectedAnalyticsMonth, _selectedAnalyticsYear, _currentUser
    ) { meals, water, month, year, user ->
        val target = user?.dailyCalorieTarget ?: 2200
        val daysInMonth = DateUtils.getDaysInMonth(year, month)
        val monthPrefix = String.format("%04d-%02d-", year, month)

        val monthMeals = meals.filter { it.dateString.startsWith(monthPrefix) }
        val monthWater = water.filter { it.dateString.startsWith(monthPrefix) }

        val calorieTrend = mutableListOf<Pair<Int, Int>>()
        val waterTrend = mutableListOf<Pair<Int, Double>>()

        var totalCal = 0
        var totalWaterMl = 0
        var trackedDays = 0

        for (day in 1..daysInMonth) {
            val dayStr = String.format("%04d-%02d-%02d", year, month, day)
            val c = monthMeals.filter { it.dateString == dayStr }.sumOf { it.calories }
            val w = monthWater.filter { it.dateString == dayStr }.sumOf { it.amountMl }

            calorieTrend.add(Pair(day, c))
            waterTrend.add(Pair(day, w / 1000.0))

            if (c > 0 || w > 0) {
                totalCal += c
                totalWaterMl += w
                trackedDays++
            }
        }

        val avgCal = if (trackedDays > 0) totalCal / trackedDays else 0
        val avgWater = if (trackedDays > 0) (totalWaterMl / trackedDays) / 1000.0 else 0.0

        MonthlyAnalytics(
            monthTitle = DateUtils.getMonthYearTitle(year, month),
            year = year,
            month = month,
            averageDailyCalories = avgCal,
            averageWaterL = avgWater,
            totalCaloriesLogged = totalCal,
            daysTracked = trackedDays,
            totalDaysInMonth = daysInMonth,
            calorieTrend = calorieTrend,
            waterTrend = waterTrend,
            calorieTarget = target
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MonthlyAnalytics())

    // All History List from real user data
    val historyList: StateFlow<List<DaySummary>> = combine(_allMeals, _allWater, _currentUser) { meals, water, user ->
        val target = user?.dailyCalorieTarget ?: 2200
        val waterTarget = user?.dailyWaterTargetMl ?: 3000

        val allDates = (meals.map { it.dateString } + water.map { it.dateString }).distinct().sortedDescending()
        allDates.map { d ->
            val c = meals.filter { it.dateString == d }.sumOf { it.calories }
            val w = water.filter { it.dateString == d }.sumOf { it.amountMl }
            val status = when {
                c == 0 && w == 0 -> "No Data"
                abs(c - target) <= 150 -> "Achieved"
                c < target -> "Under Target"
                else -> "Over Target"
            }
            DaySummary(
                dateString = d,
                dayOfWeek = DateUtils.getDayOfWeekShort(d),
                dayOfMonth = DateUtils.getDayOfMonth(d),
                monthName = DateUtils.formatShortMonthDay(d),
                totalCalories = c,
                calorieTarget = target,
                waterIntakeMl = w,
                waterTargetMl = waterTarget,
                status = status
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
