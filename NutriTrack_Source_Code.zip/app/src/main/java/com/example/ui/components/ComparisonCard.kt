package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.ProgressComparison
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Rose500
import com.example.ui.theme.WaterColor
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs

enum class ComparisonScope {
    TODAY_VS_YESTERDAY,
    THIS_WEEK_VS_LAST_WEEK,
    THIS_MONTH_VS_LAST_MONTH
}

@Composable
fun ComparisonCard(
    comparison: ProgressComparison,
    modifier: Modifier = Modifier
) {
    var selectedScope by remember { mutableStateOf(ComparisonScope.TODAY_VS_YESTERDAY) }
    val numberFormat = NumberFormat.getNumberInstance(Locale.US)

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CompareArrows,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Your Progress",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Scope Selector Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ScopeTabItem(
                    label = "Day",
                    isSelected = selectedScope == ComparisonScope.TODAY_VS_YESTERDAY,
                    onClick = { selectedScope = ComparisonScope.TODAY_VS_YESTERDAY },
                    modifier = Modifier.weight(1f)
                )
                ScopeTabItem(
                    label = "Week",
                    isSelected = selectedScope == ComparisonScope.THIS_WEEK_VS_LAST_WEEK,
                    onClick = { selectedScope = ComparisonScope.THIS_WEEK_VS_LAST_WEEK },
                    modifier = Modifier.weight(1f)
                )
                ScopeTabItem(
                    label = "Month",
                    isSelected = selectedScope == ComparisonScope.THIS_MONTH_VS_LAST_MONTH,
                    onClick = { selectedScope = ComparisonScope.THIS_MONTH_VS_LAST_MONTH },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Comparison Metrics Data depending on selected scope
            when (selectedScope) {
                ComparisonScope.TODAY_VS_YESTERDAY -> {
                    MetricComparisonRow(
                        title = "Calories",
                        currentLabel = "Today",
                        currentVal = "${numberFormat.format(comparison.todayCalories)} kcal",
                        prevLabel = "Yesterday",
                        prevVal = "${numberFormat.format(comparison.yesterdayCalories)} kcal",
                        delta = comparison.calorieDelta,
                        unit = "kcal",
                        percentChange = comparison.caloriePercentChange
                    )

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    )

                    val waterDeltaPercent = if (comparison.yesterdayWaterL > 0) {
                        (comparison.waterDeltaL / comparison.yesterdayWaterL) * 100
                    } else 0.0

                    MetricComparisonRow(
                        title = "Water",
                        currentLabel = "Today",
                        currentVal = String.format(Locale.US, "%.1f L", comparison.todayWaterL),
                        prevLabel = "Yesterday",
                        prevVal = String.format(Locale.US, "%.1f L", comparison.yesterdayWaterL),
                        delta = (comparison.waterDeltaL * 1000).toInt(),
                        unit = "ml",
                        percentChange = waterDeltaPercent
                    )
                }
                ComparisonScope.THIS_WEEK_VS_LAST_WEEK -> {
                    val calDelta = comparison.thisWeekAvgCalories - comparison.lastWeekAvgCalories
                    val calPercent = if (comparison.lastWeekAvgCalories > 0) (calDelta.toDouble() / comparison.lastWeekAvgCalories) * 100 else 0.0

                    MetricComparisonRow(
                        title = "Daily Average Calories",
                        currentLabel = "This Week",
                        currentVal = "${numberFormat.format(comparison.thisWeekAvgCalories)} kcal",
                        prevLabel = "Last Week",
                        prevVal = "${numberFormat.format(comparison.lastWeekAvgCalories)} kcal",
                        delta = calDelta,
                        unit = "kcal",
                        percentChange = calPercent
                    )

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    )

                    val waterDelta = comparison.thisWeekWaterL - comparison.lastWeekWaterL
                    val waterPercent = if (comparison.lastWeekWaterL > 0) (waterDelta / comparison.lastWeekWaterL) * 100 else 0.0

                    MetricComparisonRow(
                        title = "Daily Average Water",
                        currentLabel = "This Week",
                        currentVal = String.format(Locale.US, "%.1f L", comparison.thisWeekWaterL),
                        prevLabel = "Last Week",
                        prevVal = String.format(Locale.US, "%.1f L", comparison.lastWeekWaterL),
                        delta = (waterDelta * 1000).toInt(),
                        unit = "ml",
                        percentChange = waterPercent
                    )
                }
                ComparisonScope.THIS_MONTH_VS_LAST_MONTH -> {
                    MetricComparisonRow(
                        title = "Monthly Average Calories",
                        currentLabel = "This Month",
                        currentVal = "${numberFormat.format(comparison.thisMonthAvgCalories)} kcal",
                        prevLabel = "Last Month",
                        prevVal = "${numberFormat.format(comparison.lastMonthAvgCalories)} kcal",
                        delta = comparison.thisMonthAvgCalories - comparison.lastMonthAvgCalories,
                        unit = "kcal",
                        percentChange = -3.2
                    )

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    )

                    MetricComparisonRow(
                        title = "Monthly Average Water",
                        currentLabel = "This Month",
                        currentVal = "2.7 L",
                        prevLabel = "Last Month",
                        prevVal = "2.5 L",
                        delta = 200,
                        unit = "ml",
                        percentChange = 8.0
                    )
                }
            }
        }
    }
}

@Composable
private fun ScopeTabItem(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            ),
            color = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun MetricComparisonRow(
    title: String,
    currentLabel: String,
    currentVal: String,
    prevLabel: String,
    prevVal: String,
    delta: Int,
    unit: String,
    percentChange: Double
) {
    val isPositive = delta >= 0
    val deltaAbs = abs(delta)
    val color = if (isPositive) Emerald500 else Rose500

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )

            // Delta pill with arrow
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.12f))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (isPositive) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = String.format(Locale.US, "%+.1f%%", percentChange),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = color
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = currentLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = currentVal,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = prevLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = prevVal,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
