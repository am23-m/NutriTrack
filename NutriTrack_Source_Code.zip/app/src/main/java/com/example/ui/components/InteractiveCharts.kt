package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DaySummary
import com.example.ui.theme.Cyan400
import com.example.ui.theme.Cyan500
import com.example.ui.theme.Emerald400
import com.example.ui.theme.Emerald500
import com.example.ui.theme.WaterColor
import java.text.NumberFormat
import java.util.Locale

@Composable
fun WeeklyBarChart(
    days: List<DaySummary>,
    calorieTarget: Int,
    modifier: Modifier = Modifier
) {
    val numberFormat = NumberFormat.getNumberInstance(Locale.US)
    val maxCal = maxOf(calorieTarget + 300, (days.maxOfOrNull { it.totalCalories } ?: 2200) + 200)

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Weekly Calorie Intake",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Emerald500)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Target: ${numberFormat.format(calorieTarget)} kcal",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Bars canvas
            val trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
            val barBrush = Brush.verticalGradient(listOf(Emerald400, Emerald500))
            val targetLineColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                ) {
                    val w = size.width
                    val h = size.height - 28.dp.toPx()
                    val targetY = h * (1f - (calorieTarget.toFloat() / maxCal.toFloat()))

                    // Draw reference target dashed line
                    drawLine(
                        color = targetLineColor,
                        start = Offset(0f, targetY),
                        end = Offset(w, targetY),
                        strokeWidth = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )

                    // Draw 7 day bars
                    val count = days.size
                    if (count > 0) {
                        val barWidth = (w / count) * 0.45f
                        val stepX = w / count

                        days.forEachIndexed { i, day ->
                            val cx = stepX * i + (stepX / 2f)
                            val barHeight = (day.totalCalories.toFloat() / maxCal.toFloat()) * h

                            // Background bar capsule
                            drawRoundRect(
                                color = trackColor,
                                topLeft = Offset(cx - barWidth / 2f, 0f),
                                size = Size(barWidth, h),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
                            )

                            // Active bar
                            if (barHeight > 0) {
                                drawRoundRect(
                                    brush = barBrush,
                                    topLeft = Offset(cx - barWidth / 2f, h - barHeight),
                                    size = Size(barWidth, barHeight),
                                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
                                )
                            }
                        }
                    }
                }

                // X-Axis labels below
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    days.forEach { day ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = day.dayOfWeek,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${day.totalCalories}",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CalorieTrendChart(
    calorieTrend: List<Pair<Int, Int>>,
    targetCalories: Int,
    modifier: Modifier = Modifier
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }
    val maxVal = maxOf(targetCalories + 400, (calorieTrend.maxOfOrNull { it.second } ?: 2200) + 300)
    val numberFormat = NumberFormat.getNumberInstance(Locale.US)

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Calorie Trend",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Daily intake vs target reference (~2,200 kcal)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                selectedIndex?.let { idx ->
                    val pair = calorieTrend.getOrNull(idx)
                    if (pair != null) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Day ${pair.first}: ${numberFormat.format(pair.second)} kcal",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            val lineColor = Emerald500
            val fillColor = Brush.verticalGradient(
                listOf(Emerald400.copy(alpha = 0.35f), Emerald500.copy(alpha = 0.02f))
            )
            val refLineColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .pointerInput(calorieTrend) {
                            detectTapGestures { offset ->
                                val stepX = size.width / calorieTrend.size.coerceAtLeast(1)
                                val index = (offset.x / stepX).toInt().coerceIn(0, calorieTrend.size - 1)
                                selectedIndex = index
                            }
                        }
                ) {
                    val w = size.width
                    val h = size.height - 20.dp.toPx()
                    val targetY = h * (1f - (targetCalories.toFloat() / maxVal.toFloat()))

                    // Draw reference target dashed line
                    drawLine(
                        color = refLineColor,
                        start = Offset(0f, targetY),
                        end = Offset(w, targetY),
                        strokeWidth = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )

                    if (calorieTrend.size > 1) {
                        val stepX = w / (calorieTrend.size - 1)
                        val linePath = Path()
                        val fillPath = Path()

                        val firstX = 0f
                        val firstY = h * (1f - (calorieTrend[0].second.toFloat() / maxVal.toFloat()))

                        linePath.moveTo(firstX, firstY)
                        fillPath.moveTo(firstX, h)
                        fillPath.lineTo(firstX, firstY)

                        for (i in 1 until calorieTrend.size) {
                            val x = i * stepX
                            val y = h * (1f - (calorieTrend[i].second.toFloat() / maxVal.toFloat()))
                            val prevX = (i - 1) * stepX
                            val prevY = h * (1f - (calorieTrend[i - 1].second.toFloat() / maxVal.toFloat()))
                            val cx1 = prevX + (x - prevX) / 2f
                            val cy1 = prevY
                            val cx2 = prevX + (x - prevX) / 2f
                            val cy2 = y
                            linePath.cubicTo(cx1, cy1, cx2, cy2, x, y)
                            fillPath.cubicTo(cx1, cy1, cx2, cy2, x, y)
                        }

                        fillPath.lineTo(w, h)
                        fillPath.close()

                        // Draw shaded gradient area
                        drawPath(path = fillPath, brush = fillColor)
                        // Draw smooth line
                        drawPath(
                            path = linePath,
                            color = lineColor,
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )

                        // Draw points
                        calorieTrend.forEachIndexed { i, pair ->
                            val px = i * stepX
                            val py = h * (1f - (pair.second.toFloat() / maxVal.toFloat()))
                            val isSelected = selectedIndex == i

                            drawCircle(
                                color = if (isSelected) Color.White else lineColor,
                                radius = if (isSelected) 6.dp.toPx() else 3.5.dp.toPx(),
                                center = Offset(px, py)
                            )
                            if (isSelected) {
                                drawCircle(
                                    color = lineColor,
                                    radius = 6.dp.toPx(),
                                    center = Offset(px, py),
                                    style = Stroke(width = 2.dp.toPx())
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WaterTrendChart(
    waterTrend: List<Pair<Int, Double>>,
    modifier: Modifier = Modifier
) {
    val maxL = maxOf(4.0, (waterTrend.maxOfOrNull { it.second } ?: 3.0) + 0.5)

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Water Trend",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Daily hydration volume in Litres (L)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(WaterColor.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Target ~3.0 L",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = WaterColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            val waterLineColor = WaterColor
            val waterFillBrush = Brush.verticalGradient(
                listOf(Cyan400.copy(alpha = 0.35f), WaterColor.copy(alpha = 0.02f))
            )
            val refColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                ) {
                    val w = size.width
                    val h = size.height - 20.dp.toPx()
                    val targetY = h * (1f - (3.0f / maxL.toFloat()))

                    // Reference line 3.0 L
                    drawLine(
                        color = refColor,
                        start = Offset(0f, targetY),
                        end = Offset(w, targetY),
                        strokeWidth = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )

                    if (waterTrend.size > 1) {
                        val stepX = w / (waterTrend.size - 1)
                        val linePath = Path()
                        val fillPath = Path()

                        val firstX = 0f
                        val firstY = h * (1f - (waterTrend[0].second.toFloat() / maxL.toFloat()))

                        linePath.moveTo(firstX, firstY)
                        fillPath.moveTo(firstX, h)
                        fillPath.lineTo(firstX, firstY)

                        for (i in 1 until waterTrend.size) {
                            val x = i * stepX
                            val y = h * (1f - (waterTrend[i].second.toFloat() / maxL.toFloat()))
                            val prevX = (i - 1) * stepX
                            val prevY = h * (1f - (waterTrend[i - 1].second.toFloat() / maxL.toFloat()))
                            val cx1 = prevX + (x - prevX) / 2f
                            val cy1 = prevY
                            val cx2 = prevX + (x - prevX) / 2f
                            val cy2 = y
                            linePath.cubicTo(cx1, cy1, cx2, cy2, x, y)
                            fillPath.cubicTo(cx1, cy1, cx2, cy2, x, y)
                        }

                        fillPath.lineTo(w, h)
                        fillPath.close()

                        drawPath(path = fillPath, brush = waterFillBrush)
                        drawPath(
                            path = linePath,
                            color = waterLineColor,
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }
            }
        }
    }
}
