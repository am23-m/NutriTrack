package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBackIos
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MonthlyAnalytics
import com.example.model.ProgressComparison
import com.example.model.WeeklyAnalytics
import com.example.ui.components.CalorieTrendChart
import com.example.ui.components.ComparisonCard
import com.example.ui.components.WaterTrendChart
import com.example.ui.components.WeeklyBarChart
import com.example.ui.theme.Cyan500
import com.example.ui.theme.Emerald500
import com.example.ui.theme.WaterColor
import java.text.NumberFormat
import java.util.Locale

@Composable
fun AnalyticsScreen(
    weeklyAnalytics: WeeklyAnalytics,
    monthlyAnalytics: MonthlyAnalytics,
    comparison: ProgressComparison,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Weekly, 1 = Monthly
    val numberFormat = NumberFormat.getNumberInstance(Locale.US)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Heading & Scope Switcher (Weekly vs Monthly)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Performance Analytics",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Weekly trends and monthly health insights",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Tab switch
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selectedTab == 0) MaterialTheme.colorScheme.surface else Color.Transparent)
                        .clickable { selectedTab = 0 }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("analytics_weekly_tab")
                ) {
                    Text(
                        text = "Weekly",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (selectedTab == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selectedTab == 1) MaterialTheme.colorScheme.surface else Color.Transparent)
                        .clickable { selectedTab = 1 }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("analytics_monthly_tab")
                ) {
                    Text(
                        text = "Monthly",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (selectedTab == 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (selectedTab == 0) {
            // Weekly KPI Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "Avg Calories",
                    value = "${numberFormat.format(weeklyAnalytics.averageCalories)} kcal",
                    icon = Icons.Default.LocalFireDepartment,
                    color = Emerald500,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "Avg Water",
                    value = String.format(Locale.US, "%.1f L", weeklyAnalytics.averageWaterL),
                    icon = Icons.Default.LocalDrink,
                    color = WaterColor,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "Best Hydration",
                    value = weeklyAnalytics.bestHydrationDay,
                    icon = Icons.Default.CheckCircle,
                    color = Cyan500,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "Target Hit",
                    value = "${weeklyAnalytics.targetCompletionPercentage}%",
                    icon = Icons.Default.CalendarMonth,
                    color = Emerald500,
                    modifier = Modifier.weight(1f)
                )
            }

            // Weekly 7-Day Bar Chart
            WeeklyBarChart(
                days = weeklyAnalytics.days,
                calorieTarget = monthlyAnalytics.calorieTarget
            )
        } else {
            // Month Selector Bar: < September 2026 >
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onPreviousMonth) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBackIos,
                            contentDescription = "Previous Month",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Text(
                        text = monthlyAnalytics.monthTitle,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    IconButton(onClick = onNextMonth) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                            contentDescription = "Next Month",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Monthly 4 KPI Cards (Section 11)
            // Average Daily Calories: 2,080 kcal
            // Average Water: 2.7 L
            // Calories Logged: 14,560 kcal
            // Days Tracked: 7 / 30
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "Avg Daily Calories",
                    value = "${numberFormat.format(monthlyAnalytics.averageDailyCalories)} kcal",
                    icon = Icons.Default.LocalFireDepartment,
                    color = Emerald500,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "Avg Water",
                    value = String.format(Locale.US, "%.1f L", monthlyAnalytics.averageWaterL),
                    icon = Icons.Default.LocalDrink,
                    color = WaterColor,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "Calories Logged",
                    value = "${numberFormat.format(monthlyAnalytics.totalCaloriesLogged)} kcal",
                    icon = Icons.Default.CalendarMonth,
                    color = Cyan500,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "Days Tracked",
                    value = "${monthlyAnalytics.daysTracked} / ${monthlyAnalytics.totalDaysInMonth}",
                    icon = Icons.Default.CheckCircle,
                    color = Emerald500,
                    modifier = Modifier.weight(1f)
                )
            }

            // Monthly Calorie Trend Chart
            CalorieTrendChart(
                calorieTrend = monthlyAnalytics.calorieTrend,
                targetCalories = monthlyAnalytics.calorieTarget
            )

            // Monthly Water Trend Chart
            WaterTrendChart(
                waterTrend = monthlyAnalytics.waterTrend
            )
        }

        // Progress Comparison Card
        ComparisonCard(comparison = comparison)

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
private fun KpiCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(color.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
