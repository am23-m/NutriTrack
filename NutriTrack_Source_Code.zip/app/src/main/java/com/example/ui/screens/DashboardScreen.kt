package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MealItemEntity
import com.example.data.UserEntity
import com.example.data.WaterEntryEntity
import com.example.model.MealType
import com.example.model.ProgressComparison
import com.example.model.Screen
import com.example.ui.components.CalorieOverviewCard
import com.example.ui.components.ComparisonCard
import com.example.ui.components.DateNavigationStrip
import com.example.ui.components.MealCard
import com.example.ui.components.WaterOverviewCard
import com.example.ui.theme.Emerald500
import com.example.ui.theme.WaterColor

@Composable
fun DashboardScreen(
    currentUser: UserEntity?,
    selectedDate: String,
    meals: List<MealItemEntity>,
    water: List<WaterEntryEntity>,
    comparison: ProgressComparison,
    onPreviousDay: () -> Unit,
    onNextDay: () -> Unit,
    onToday: () -> Unit,
    onSelectDateClick: () -> Unit,
    onOpenAddFood: (MealType) -> Unit,
    onDeleteFood: (Long) -> Unit,
    onQuickAddWater: (Int) -> Unit,
    onCustomAddWaterClick: () -> Unit,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalCalories = meals.sumOf { it.calories }
    val totalWaterMl = water.sumOf { it.amountMl }
    val targetCalories = currentUser?.dailyCalorieTarget ?: 2200
    val targetWaterMl = currentUser?.dailyWaterTargetMl ?: 3000

    val breakfastItems = meals.filter { it.mealType.equals(MealType.BREAKFAST.id, ignoreCase = true) }
    val lunchItems = meals.filter { it.mealType.equals(MealType.LUNCH.id, ignoreCase = true) }
    val eveningItems = meals.filter { it.mealType.equals(MealType.EVENING.id, ignoreCase = true) }
    val dinnerItems = meals.filter { it.mealType.equals(MealType.DINNER.id, ignoreCase = true) }
    val extraItems = meals.filter { it.mealType.equals(MealType.EXTRA.id, ignoreCase = true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Date Selector Bar
        DateNavigationStrip(
            selectedDate = selectedDate,
            onPreviousDay = onPreviousDay,
            onNextDay = onNextDay,
            onToday = onToday,
            onSelectDateClick = onSelectDateClick
        )

        // Quick Actions (Add Food, Add Water, View History, View Analytics)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QuickActionButton(
                icon = Icons.Default.Restaurant,
                label = "+ Food",
                color = Emerald500,
                onClick = { onOpenAddFood(MealType.BREAKFAST) },
                modifier = Modifier.weight(1f),
                tag = "dashboard_add_food_btn"
            )
            QuickActionButton(
                icon = Icons.Default.LocalDrink,
                label = "+ Water",
                color = WaterColor,
                onClick = { onQuickAddWater(250) },
                modifier = Modifier.weight(1f),
                tag = "dashboard_add_water_btn"
            )
            QuickActionButton(
                icon = Icons.Default.History,
                label = "History",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                onClick = { onNavigate(Screen.HISTORY) },
                modifier = Modifier.weight(1f),
                tag = "dashboard_history_btn"
            )
            QuickActionButton(
                icon = Icons.Default.Analytics,
                label = "Analytics",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                onClick = { onNavigate(Screen.ANALYTICS) },
                modifier = Modifier.weight(1f),
                tag = "dashboard_analytics_btn"
            )
        }

        // Today's Calorie Overview Card (Circular progress, 1,680 / 2,200 kcal, comparison vs yesterday)
        CalorieOverviewCard(
            consumedCalories = totalCalories,
            targetCalories = targetCalories,
            yesterdayCalories = comparison.yesterdayCalories
        )

        // Water Overview Card (1.8 L / 3.0 L, 7/12 glasses, quick buttons)
        WaterOverviewCard(
            currentWaterMl = totalWaterMl,
            targetWaterMl = targetWaterMl,
            onQuickAdd = onQuickAddWater,
            onCustomAddClick = onCustomAddWaterClick
        )

        // Meal Breakdown Section Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Meal Breakdown",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "5 categories",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // 5 Meal Cards (Breakfast -> Lunch -> Evening -> Dinner -> Extra)
        MealCard(
            mealType = MealType.BREAKFAST,
            items = breakfastItems,
            targetCalories = currentUser?.breakfastTarget ?: 500,
            onAddFoodClick = { onOpenAddFood(MealType.BREAKFAST) },
            onDeleteItemClick = onDeleteFood
        )

        MealCard(
            mealType = MealType.LUNCH,
            items = lunchItems,
            targetCalories = currentUser?.lunchTarget ?: 650,
            onAddFoodClick = { onOpenAddFood(MealType.LUNCH) },
            onDeleteItemClick = onDeleteFood
        )

        MealCard(
            mealType = MealType.EVENING,
            items = eveningItems,
            targetCalories = currentUser?.eveningTarget ?: 400,
            onAddFoodClick = { onOpenAddFood(MealType.EVENING) },
            onDeleteItemClick = onDeleteFood
        )

        MealCard(
            mealType = MealType.DINNER,
            items = dinnerItems,
            targetCalories = currentUser?.dinnerTarget ?: 650,
            onAddFoodClick = { onOpenAddFood(MealType.DINNER) },
            onDeleteItemClick = onDeleteFood
        )

        MealCard(
            mealType = MealType.EXTRA,
            items = extraItems,
            targetCalories = currentUser?.extraTarget ?: 250,
            onAddFoodClick = { onOpenAddFood(MealType.EXTRA) },
            onDeleteItemClick = onDeleteFood
        )

        // Comparison Progress Card (Today vs Yesterday, This Week vs Last Week, Month)
        ComparisonCard(comparison = comparison)

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
private fun QuickActionButton(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tag: String
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(color.copy(alpha = 0.1f))
            .clickable { onClick() }
            .padding(vertical = 12.dp)
            .testTag(tag),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = color
            )
        }
    }
}
