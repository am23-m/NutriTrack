package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Health-tech Emerald & Cyan Brand Colors
val Emerald500 = Color(0xFF10B981)
val Emerald600 = Color(0xFF059669)
val Emerald400 = Color(0xFF34D399)
val Emerald100 = Color(0xFFD1FAE5)

val Cyan500 = Color(0xFF06B6D4)
val Cyan400 = Color(0xFF22D3EE)
val Cyan600 = Color(0xFF0891B2)
val Cyan100 = Color(0xFFCFFAFE)

val Amber500 = Color(0xFFF59E0B)
val Amber100 = Color(0xFFFEF3C7)
val Rose500 = Color(0xFFF43F5E)
val Rose100 = Color(0xFFFFE4E6)
val Indigo500 = Color(0xFF6366F1)
val Indigo100 = Color(0xFFE0E7FF)

// Neutrals - Light
val NeutralBackgroundLight = Color(0xFFF8FAFC)
val NeutralSurfaceLight = Color(0xFFFFFFFF)
val NeutralSurfaceVariantLight = Color(0xFFF1F5F9)
val NeutralBorderLight = Color(0xFFE2E8F0)
val NeutralTextPrimaryLight = Color(0xFF0F172A)
val NeutralTextSecondaryLight = Color(0xFF64748B)
val NeutralTextTertiaryLight = Color(0xFF94A3B8)

// Neutrals - Dark
val NeutralBackgroundDark = Color(0xFF0B0F19)
val NeutralSurfaceDark = Color(0xFF131D31)
val NeutralSurfaceVariantDark = Color(0xFF1E293B)
val NeutralBorderDark = Color(0xFF2E3D56)
val NeutralTextPrimaryDark = Color(0xFFF8FAFC)
val NeutralTextSecondaryDark = Color(0xFF94A3B8)
val NeutralTextTertiaryDark = Color(0xFF64748B)

// Meal Categories
val BreakfastColor = Color(0xFFF97316) // Sunrise orange
val LunchColor = Color(0xFFF59E0B)     // Midday golden amber
val EveningColor = Color(0xFF10B981)   // Emerald green
val DinnerColor = Color(0xFF6366F1)    // Twilight indigo
val ExtraColor = Color(0xFFEC4899)     // Warm pink
val WaterColor = Color(0xFF0EA5E9)     // Pure sky cyan
