package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Emerald400,
    onPrimary = Color(0xFF003822),
    primaryContainer = Color(0xFF064E3B),
    onPrimaryContainer = Emerald100,

    secondary = Cyan400,
    onSecondary = Color(0xFF00363F),
    secondaryContainer = Color(0xFF155E75),
    onSecondaryContainer = Cyan100,

    tertiary = Amber500,
    onTertiary = Color(0xFF452B00),

    background = NeutralBackgroundDark,
    onBackground = NeutralTextPrimaryDark,
    surface = NeutralSurfaceDark,
    onSurface = NeutralTextPrimaryDark,
    surfaceVariant = NeutralSurfaceVariantDark,
    onSurfaceVariant = NeutralTextSecondaryDark,
    outline = NeutralBorderDark,
    outlineVariant = Color(0xFF1E293B)
)

private val LightColorScheme = lightColorScheme(
    primary = Emerald600,
    onPrimary = Color.White,
    primaryContainer = Emerald100,
    onPrimaryContainer = Color(0xFF064E3B),

    secondary = Cyan600,
    onSecondary = Color.White,
    secondaryContainer = Cyan100,
    onSecondaryContainer = Color(0xFF164E63),

    tertiary = Amber500,
    onTertiary = Color.White,

    background = NeutralBackgroundLight,
    onBackground = NeutralTextPrimaryLight,
    surface = NeutralSurfaceLight,
    onSurface = NeutralTextPrimaryLight,
    surfaceVariant = NeutralSurfaceVariantLight,
    onSurfaceVariant = NeutralTextSecondaryLight,
    outline = NeutralBorderLight,
    outlineVariant = Color(0xFFE2E8F0)
)

@Composable
fun NutriTrackTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
