package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {
    private val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
    private val fullDisplayFormat = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.ENGLISH)
    private val headerDisplayFormat = SimpleDateFormat("EEEE, MMMM d", Locale.ENGLISH)
    private val shortMonthDayFormat = SimpleDateFormat("MMM d", Locale.ENGLISH)
    private val dayOfWeekFormat = SimpleDateFormat("EEE", Locale.ENGLISH)
    private val dayOfWeekFullFormat = SimpleDateFormat("EEEE", Locale.ENGLISH)
    private val monthYearFormat = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)

    @Synchronized
    fun formatDisplayDate(dateString: String): String {
        return try {
            val date = isoFormat.parse(dateString) ?: return dateString
            fullDisplayFormat.format(date)
        } catch (_: Exception) {
            dateString
        }
    }

    @Synchronized
    fun formatHeaderDate(dateString: String): String {
        return try {
            val date = isoFormat.parse(dateString) ?: return dateString
            headerDisplayFormat.format(date)
        } catch (_: Exception) {
            dateString
        }
    }

    @Synchronized
    fun formatShortMonthDay(dateString: String): String {
        return try {
            val date = isoFormat.parse(dateString) ?: return dateString
            shortMonthDayFormat.format(date)
        } catch (_: Exception) {
            dateString
        }
    }

    @Synchronized
    fun getDayOfWeekShort(dateString: String): String {
        return try {
            val date = isoFormat.parse(dateString) ?: return "—"
            dayOfWeekFormat.format(date)
        } catch (_: Exception) {
            "—"
        }
    }

    @Synchronized
    fun getDayOfWeekFull(dateString: String): String {
        return try {
            val date = isoFormat.parse(dateString) ?: return "—"
            dayOfWeekFullFormat.format(date)
        } catch (_: Exception) {
            "—"
        }
    }

    @Synchronized
    fun getDayOfMonth(dateString: String): Int {
        return try {
            val cal = Calendar.getInstance()
            val date = isoFormat.parse(dateString) ?: return 1
            cal.time = date
            cal.get(Calendar.DAY_OF_MONTH)
        } catch (_: Exception) {
            1
        }
    }

    @Synchronized
    fun addDays(dateString: String, days: Int): String {
        return try {
            val cal = Calendar.getInstance()
            val date = isoFormat.parse(dateString) ?: Date()
            cal.time = date
            cal.add(Calendar.DAY_OF_YEAR, days)
            isoFormat.format(cal.time)
        } catch (_: Exception) {
            dateString
        }
    }

    @Synchronized
    fun getMonthYearTitle(year: Int, month: Int): String {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        return monthYearFormat.format(cal.time)
    }

    @Synchronized
    fun getTodayDate(): String {
        return isoFormat.format(Date())
    }

    @Synchronized
    fun getSystemTodayDate(): String {
        return isoFormat.format(Date())
    }

    @Synchronized
    fun getDaysInMonth(year: Int, month: Int): Int {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1)
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    @Synchronized
    fun getFirstDayOfWeekInMonth(year: Int, month: Int): Int {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        // Calendar.SUNDAY = 1, MONDAY = 2, etc.
        // Return 0 for Mon, 1 for Tue, ..., 6 for Sun
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        return if (dow == Calendar.SUNDAY) 6 else dow - 2
    }
}
