package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.DailyRecordEntity
import com.example.data.MealItemEntity
import com.example.data.NutriTrackDatabase
import com.example.data.NutriTrackRepository
import com.example.data.SessionManager
import com.example.data.WaterEntryEntity
import com.example.model.MealType
import com.example.util.DateUtils
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DataPersistenceAndHistoryTest {

    private lateinit var database: NutriTrackDatabase
    private lateinit var context: Context
    private lateinit var sessionManager: SessionManager
    private lateinit var repository: NutriTrackRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext<Context>()
        sessionManager = SessionManager(context)
        sessionManager.clearSession()

        database = Room.inMemoryDatabaseBuilder(
            context,
            NutriTrackDatabase::class.java
        ).allowMainThreadQueries().build()

        repository = NutriTrackRepository(database.dao(), sessionManager)
    }

    @After
    fun tearDown() {
        sessionManager.clearSession()
        database.close()
    }

    @Test
    fun testStartupAndAuthenticationFlow() = runBlocking {
        // Requirement 1 & 4: Fresh app open -> no logged in session
        assertNull("Initial session must be null for fresh app install", repository.getActiveUserId())

        // Create User A
        val userA = repository.registerUser(
            name = "User A",
            mobile = "1111111111",
            passwordHash = "passwordA",
            weightKg = 65.5
        )
        assertNotNull(userA.userId)
        assertEquals("User A", userA.name)
        assertEquals(65.5, userA.weightKg, 0.01)

        // Save session on login/registration
        repository.saveSession(userA.userId)
        assertEquals(userA.userId, repository.getActiveUserId())

        // Verify returning user retrieval
        val sessionUser = repository.getUserById(repository.getActiveUserId()!!)
        assertNotNull(sessionUser)
        assertEquals(userA.userId, sessionUser?.userId)
        assertEquals("User A", sessionUser?.name)

        // Logout -> clears session
        repository.clearSession()
        assertNull("Session must be cleared upon logout", repository.getActiveUserId())
    }

    @Test
    fun testUserIsolation_UserACannotSeeUserBData() = runBlocking {
        // Register User A
        val userA = repository.registerUser("User A", "1111111111", "passA", 65.0)
        // Register User B
        val userB = repository.registerUser("User B", "2222222222", "passB", 80.0)

        assertNotEquals(userA.userId, userB.userId)

        val date = "2026-09-26"

        // User A logs food and water
        repository.insertMeal(
            MealItemEntity(
                userId = userA.userId,
                dateString = date,
                mealType = MealType.BREAKFAST.id,
                foodName = "Oatmeal",
                quantity = 1.0,
                unit = "bowl",
                calories = 350
            )
        )
        repository.insertWater(
            WaterEntryEntity(
                userId = userA.userId,
                dateString = date,
                amountMl = 500
            )
        )

        // Verify User A has data
        val userAMeals = repository.getAllMealsForUser(userA.userId).first()
        val userAWater = repository.getAllWaterForUser(userA.userId).first()
        assertEquals(1, userAMeals.size)
        assertEquals(350, userAMeals.sumOf { it.calories })
        assertEquals(500, userAWater.sumOf { it.amountMl })

        // Verify User B has ZERO data (strict isolation)
        val userBMeals = repository.getAllMealsForUser(userB.userId).first()
        val userBWater = repository.getAllWaterForUser(userB.userId).first()
        assertTrue("User B must NOT see User A's meals", userBMeals.isEmpty())
        assertTrue("User B must NOT see User A's water", userBWater.isEmpty())

        // User B enters their own meal
        repository.insertMeal(
            MealItemEntity(
                userId = userB.userId,
                dateString = date,
                mealType = MealType.DINNER.id,
                foodName = "Steak Salad",
                quantity = 1.0,
                unit = "plate",
                calories = 600
            )
        )

        // Verify User B sees only their meal
        val userBMealsAfter = repository.getAllMealsForUser(userB.userId).first()
        assertEquals(1, userBMealsAfter.size)
        assertEquals("Steak Salad", userBMealsAfter[0].foodName)

        // User A still has only their original meal
        val userAMealsAfter = repository.getAllMealsForUser(userA.userId).first()
        assertEquals(1, userAMealsAfter.size)
        assertEquals("Oatmeal", userAMealsAfter[0].foodName)
    }

    @Test
    fun testDateWiseDataSeparation_NoOverwritesAcrossDays() = runBlocking {
        // Requirement 9: Save data separately for every day
        val user = repository.registerUser("User A", "1111111111", "passA", 70.0)
        val day1 = "2026-09-26"
        val day2 = "2026-09-27"

        // Day 1: Log 1800 calories, 2500 ml water across meals including Lunch
        repository.insertMeal(
            MealItemEntity(
                userId = user.userId,
                dateString = day1,
                mealType = MealType.BREAKFAST.id,
                foodName = "Eggs & Toast",
                quantity = 1.0,
                unit = "serving",
                calories = 500
            )
        )
        repository.insertMeal(
            MealItemEntity(
                userId = user.userId,
                dateString = day1,
                mealType = MealType.LUNCH.id,
                foodName = "Rice & Dal Bowl",
                quantity = 1.0,
                unit = "serving",
                calories = 600
            )
        )
        repository.insertMeal(
            MealItemEntity(
                userId = user.userId,
                dateString = day1,
                mealType = MealType.EVENING.id,
                foodName = "Chicken Bowl",
                quantity = 1.0,
                unit = "serving",
                calories = 300
            )
        )
        repository.insertMeal(
            MealItemEntity(
                userId = user.userId,
                dateString = day1,
                mealType = MealType.DINNER.id,
                foodName = "Soup & Salad",
                quantity = 1.0,
                unit = "serving",
                calories = 400
            )
        )
        repository.insertWater(
            WaterEntryEntity(
                userId = user.userId,
                dateString = day1,
                amountMl = 2500
            )
        )

        // Verify Day 1 data
        val day1Meals = repository.getMealsByDate(user.userId, day1).first()
        val day1Water = repository.getWaterByDate(user.userId, day1).first()
        assertEquals(1800, day1Meals.sumOf { it.calories })
        assertEquals(2500, day1Water.sumOf { it.amountMl })

        // Check DailyRecordEntity for Day 1
        val day1Record = repository.getDailyRecord(user.userId, day1)
        assertNotNull(day1Record)
        assertEquals(1800, day1Record?.totalCalories)
        assertEquals(2500, day1Record?.waterIntakeMl)

        // Day 2 (Next Day): Ensure a fresh daily record is created
        val day2InitialRecord = repository.ensureDailyRecord(
            user.userId,
            day2,
            user.dailyCalorieTarget,
            user.dailyWaterTargetMl
        )
        assertEquals(0, day2InitialRecord.totalCalories)
        assertEquals(0, day2InitialRecord.waterIntakeMl)

        // Verify Day 2 has no meals initially
        val day2MealsInitial = repository.getMealsByDate(user.userId, day2).first()
        assertTrue("Day 2 must start with 0 meals", day2MealsInitial.isEmpty())

        // Day 2: Log 2100 calories and 3000 ml water
        repository.insertMeal(
            MealItemEntity(
                userId = user.userId,
                dateString = day2,
                mealType = MealType.BREAKFAST.id,
                foodName = "Pancakes",
                quantity = 1.0,
                unit = "serving",
                calories = 700
            )
        )
        repository.insertMeal(
            MealItemEntity(
                userId = user.userId,
                dateString = day2,
                mealType = MealType.DINNER.id,
                foodName = "Pasta Feast",
                quantity = 1.0,
                unit = "serving",
                calories = 1400
            )
        )
        repository.insertWater(
            WaterEntryEntity(
                userId = user.userId,
                dateString = day2,
                amountMl = 3000
            )
        )

        // Verify Day 2 data
        val day2Meals = repository.getMealsByDate(user.userId, day2).first()
        val day2Water = repository.getWaterByDate(user.userId, day2).first()
        assertEquals(2100, day2Meals.sumOf { it.calories })
        assertEquals(3000, day2Water.sumOf { it.amountMl })

        // CRITICAL CHECK: Go back to Day 1 history. Day 1 MUST BE UNCHANGED!
        val day1MealsRechecked = repository.getMealsByDate(user.userId, day1).first()
        val day1WaterRechecked = repository.getWaterByDate(user.userId, day1).first()
        assertEquals("Day 1 calories must remain 1800", 1800, day1MealsRechecked.sumOf { it.calories })
        assertEquals("Day 1 water must remain 2500 ml", 2500, day1WaterRechecked.sumOf { it.amountMl })

        val day1RecordRechecked = repository.getDailyRecord(user.userId, day1)
        assertEquals(1800, day1RecordRechecked?.totalCalories)
        assertEquals(2500, day1RecordRechecked?.waterIntakeMl)

        val day2RecordRechecked = repository.getDailyRecord(user.userId, day2)
        assertEquals(2100, day2RecordRechecked?.totalCalories)
        assertEquals(3000, day2RecordRechecked?.waterIntakeMl)
    }

    @Test
    fun testProfileAndWeightPersistence() = runBlocking {
        val user = repository.registerUser("Alice", "9998887776", "secret", 60.0)
        assertEquals(60.0, user.weightKg, 0.01)

        val updated = user.copy(
            name = "Alice Wonder",
            weightKg = 58.5,
            dailyCalorieTarget = 2000,
            dailyWaterTargetMl = 2800
        )
        repository.updateUser(updated)

        val loaded = repository.getUserById(user.userId)
        assertNotNull(loaded)
        assertEquals("Alice Wonder", loaded?.name)
        assertEquals(58.5, loaded?.weightKg ?: 0.0, 0.01)
        assertEquals(2000, loaded?.dailyCalorieTarget)
        assertEquals(2800, loaded?.dailyWaterTargetMl)
    }

    @Test
    fun testLunchMealLoggingAndDateIsolation() = runBlocking {
        val user = repository.registerUser("Charlie", "5556667777", "passC", 72.0)
        val today = "2026-09-26"
        val tomorrow = "2026-09-27"

        // Log Lunch for Today
        repository.insertMeal(
            MealItemEntity(
                userId = user.userId,
                dateString = today,
                mealType = MealType.LUNCH.id,
                foodName = "Grilled Chicken Salad",
                quantity = 1.0,
                unit = "bowl",
                calories = 450
            )
        )

        // Verify Today has 1 Lunch meal
        val todayMeals = repository.getMealsByDate(user.userId, today).first()
        val todayLunch = todayMeals.filter { it.mealType == MealType.LUNCH.id }
        assertEquals(1, todayLunch.size)
        assertEquals("Grilled Chicken Salad", todayLunch[0].foodName)
        assertEquals(450, todayLunch[0].calories)

        // Verify Tomorrow has 0 meals initially
        val tomorrowMealsInitial = repository.getMealsByDate(user.userId, tomorrow).first()
        val tomorrowLunchInitial = tomorrowMealsInitial.filter { it.mealType == MealType.LUNCH.id }
        assertTrue("Tomorrow lunch must initially be empty", tomorrowLunchInitial.isEmpty())

        // Log a different Lunch for Tomorrow
        repository.insertMeal(
            MealItemEntity(
                userId = user.userId,
                dateString = tomorrow,
                mealType = MealType.LUNCH.id,
                foodName = "Paneer Tikka Wrap",
                quantity = 1.0,
                unit = "wrap",
                calories = 520
            )
        )

        // Verify Tomorrow has its separate Lunch record
        val tomorrowMeals = repository.getMealsByDate(user.userId, tomorrow).first()
        val tomorrowLunch = tomorrowMeals.filter { it.mealType == MealType.LUNCH.id }
        assertEquals(1, tomorrowLunch.size)
        assertEquals("Paneer Tikka Wrap", tomorrowLunch[0].foodName)
        assertEquals(520, tomorrowLunch[0].calories)

        // Verify Today's Lunch record is completely untouched and intact
        val todayMealsRechecked = repository.getMealsByDate(user.userId, today).first()
        val todayLunchRechecked = todayMealsRechecked.filter { it.mealType == MealType.LUNCH.id }
        assertEquals(1, todayLunchRechecked.size)
        assertEquals("Grilled Chicken Salad", todayLunchRechecked[0].foodName)
        assertEquals(450, todayLunchRechecked[0].calories)
    }
}
