package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.DateUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("NutriTrack", appName)
  }

  @Test
  fun `test date formatting and day calculations`() {
    val date = "2026-09-28"
    val display = DateUtils.formatDisplayDate(date)
    assertTrue(display.contains("September 28, 2026"))

    val nextDay = DateUtils.addDays(date, 1)
    assertEquals("2026-09-29", nextDay)

    val prevDay = DateUtils.addDays(date, -1)
    assertEquals("2026-09-27", prevDay)

    val dayOfWeek = DateUtils.getDayOfWeekShort(date)
    assertEquals("Mon", dayOfWeek)
  }
}
